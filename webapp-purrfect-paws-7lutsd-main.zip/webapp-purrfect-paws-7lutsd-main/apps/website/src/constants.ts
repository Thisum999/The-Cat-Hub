export const WEBSITE_NAME = "Golex";

import { Link } from "react-router-dom";
import { PawPrint, Instagram, Twitter, Facebook } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card text-card-foreground border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2">
              <img 
                src="https://storage.googleapis.com/fenado-ai-farm-public/generated/f4794f9f-d402-4f4e-96f3-5006fab4bdb3.png" 
                alt="The Cat Hub Logo" 
                className="h-10 w-auto" 
              />
              <span className="text-foreground font-semibold text-xl">The Cat Hub</span>
            </Link>
            <p className="mt-4 text-muted-foreground">
              Your ultimate guide to a happy cat. From health tips and fun tricks to the best toys,
              explore our world dedicated to your feline friend.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Instagram className="w-5 h-5" />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="w-5 h-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Facebook className="w-5 h-5" />
                <span className="sr-only">Facebook</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-medium text-lg mb-4 flex items-center gap-2">
              <PawPrint className="w-4 h-4 text-primary" />
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/tricks" className="text-muted-foreground hover:text-primary transition-colors">
                  Cat Tricks
                </Link>
              </li>
              <li>
                <Link to="/food-guide" className="text-muted-foreground hover:text-primary transition-colors">
                  Food Guide
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Store
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Store Categories */}
          <div>
            <h3 className="font-medium text-lg mb-4 flex items-center gap-2">
              <PawPrint className="w-4 h-4 text-primary" />
              Store Categories
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Toys & Entertainment
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Beds & Furniture
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Grooming Supplies
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Food & Treats
                </Link>
              </li>
              <li>
                <Link to="/store" className="text-muted-foreground hover:text-primary transition-colors">
                  Accessories
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="paws-section-divider"></div>
        
        <div className="text-center text-muted-foreground text-sm">
          <p>© 2024 The Cat Hub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
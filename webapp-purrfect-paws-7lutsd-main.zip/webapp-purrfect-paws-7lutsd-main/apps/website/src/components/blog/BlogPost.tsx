import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { getBlogPostById } from "@/lib/mock-blog-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, ChevronLeft, Share2 } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { marked } from "marked";
import "./blog.css";

const BlogPost = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const post = id ? getBlogPostById(id) : undefined;
  
  useEffect(() => {
    if (!post) {
      navigate("/blog", { replace: true });
    } else {
      document.title = `${post.title} | The Cat Hub Blog`;
    }
  }, [post, navigate]);
  
  if (!post) {
    return null;
  }
  
  const handleShare = () => {
    // In a real app, this would use the Web Share API
    // For the prototype, we'll just show a toast
    toast.success("Share link copied to clipboard!", {
      description: "You can now share this article with your friends."
    });
  };
  
  // Parse markdown content to HTML
  const contentHtml = marked(post.content);
  
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <Button 
        variant="ghost" 
        size="sm" 
        className="mb-6 text-muted-foreground"
        onClick={() => navigate("/blog")}
      >
        <ChevronLeft className="mr-1 h-4 w-4" />
        Back to all posts
      </Button>
      
      <div className="space-y-8">
        {/* Header */}
        <div>
          <div className="flex flex-wrap gap-2 mb-3">
            {post.tags.map((tag, index) => (
              <Badge key={index} variant="outline">
                {tag}
              </Badge>
            ))}
          </div>
          
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            {post.title}
          </h1>
          
          <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8 text-muted-foreground">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src={post.author.avatar} alt={post.author.name} />
                <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span>{post.author.name}</span>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                <span>{post.publishedDate}</span>
              </div>
              
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                <span>{post.readingTime} min read</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Featured Image */}
        <div className="rounded-lg overflow-hidden">
          <img 
            src={post.coverImage} 
            alt={post.title}
            className="w-full h-auto object-cover"
          />
        </div>
        
        {/* Content */}
        <div 
          className="prose prose-lg dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={{ __html: contentHtml }}
        />
        
        {/* Footer */}
        <div className="border-t pt-6 mt-12 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex flex-wrap gap-2">
            <span className="text-muted-foreground">Tags:</span>
            {post.tags.map((tag, index) => (
              <Badge key={index} variant="outline">
                {tag}
              </Badge>
            ))}
          </div>
          
          <Button onClick={handleShare} variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BlogPost;
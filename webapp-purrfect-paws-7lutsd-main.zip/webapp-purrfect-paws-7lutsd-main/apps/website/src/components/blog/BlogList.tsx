import { Link } from "react-router-dom";
import { blogPosts, generateTodayDate } from "@/lib/mock-blog-data";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Calendar } from "lucide-react";

const BlogList = () => {
  const currentDate = generateTodayDate();

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">The Cat Hub Blog</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Daily updates, tips, and stories about our feline friends.
          <span className="block mt-2 text-sm">Today: {currentDate}</span>
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogPosts.map((post) => (
          <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="aspect-video overflow-hidden">
              <img 
                src={post.coverImage} 
                alt={post.title} 
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
            
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className="text-xs font-normal">
                  {post.tags[0]}
                </Badge>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>{post.readingTime} min read</span>
                </div>
              </div>
              
              <CardTitle className="text-xl">
                <Link 
                  to={`/blog/${post.id}`}
                  className="hover:text-primary transition-colors duration-200"
                >
                  {post.title}
                </Link>
              </CardTitle>
              
              <CardDescription className="line-clamp-2">
                {post.excerpt}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="flex items-center gap-3">
                <img 
                  src={post.author.avatar} 
                  alt={post.author.name}
                  className="h-8 w-8 rounded-full object-cover"
                />
                <div>
                  <p className="text-sm font-medium">{post.author.name}</p>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{post.publishedDate}</span>
                  </div>
                </div>
              </div>
            </CardContent>
            
            <CardFooter>
              <Link 
                to={`/blog/${post.id}`}
                className="text-primary font-medium text-sm hover:underline"
              >
                Read more →
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default BlogList;
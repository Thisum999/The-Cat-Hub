import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { PawPrint, ShoppingBag } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-to-b from-background to-secondary/10 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='hsl(var(--primary))' fill-opacity='0.3'%3E%3Cpath d='M10 10c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm40 40c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zM10 50c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm40-40c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: '60px 60px'
        }}></div>
      </div>

      {/* Hero content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 z-10 flex flex-col lg:flex-row items-center gap-8 lg:gap-16">
        {/* Text content */}
        <motion.div 
          className="w-full lg:w-1/2 text-center lg:text-left"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            <span className="text-gradient">Everything Your Cat</span> <br />
            Wishes You Knew
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto lg:mx-0">
            From health tips and fun tricks to the best toys, explore our world dedicated to your feline friend.
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
            <Button 
              asChild 
              size="lg" 
              className="bg-primary text-primary-foreground hover:bg-primary/90 paws-button"
            >
              <Link to="/store">
                <ShoppingBag className="w-5 h-5" />
                <span>Explore The Store</span>
              </Link>
            </Button>
            
            <Button 
              asChild 
              size="lg" 
              variant="outline" 
              className="border-primary text-foreground hover:bg-primary/10 hover:text-primary paws-button"
            >
              <Link to="/tricks">
                <PawPrint className="w-5 h-5" />
                <span>Learn Cat Tricks</span>
              </Link>
            </Button>
          </div>
        </motion.div>
        
        {/* Hero image */}
        <motion.div 
          className="w-full lg:w-1/2"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-accent/30 rounded-full blur-xl opacity-30"></div>
            <img 
              src="https://storage.googleapis.com/fenado-ai-farm-public/generated/d4119fc4-3852-4b0f-a4dc-6d4d45099454.webp"
              alt="Happy cat lounging in sunlight" 
              className="w-full h-auto object-cover rounded-3xl shadow-xl image-wobble"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";

const CtaSection = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://storage.googleapis.com/fenado-ai-farm-public/generated/54bbdd23-6f6c-46d7-a0c0-b4532d5b2078.webp" 
          alt="Kittens playing" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/95"></div>
      </div>
      
      <motion.div 
        className="max-w-4xl mx-auto text-center relative z-10"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
      >
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6">
          Ready to <span className="text-gradient">Spoil</span> Your Furry Friend?
        </h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Discover our curated collection of cat products that your feline friend will absolutely love. Every purchase helps support our site!
        </p>
        <Button 
          asChild
          size="lg" 
          className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 py-6 paws-button"
        >
          <Link to="/store">
            <ShoppingBag className="w-5 h-5" />
            <span>Shop All Cat Goodies</span>
          </Link>
        </Button>
      </motion.div>
    </section>
  );
};

export default CtaSection;
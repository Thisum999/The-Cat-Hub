import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Quote } from "lucide-react";

const testimonials = [
  {
    quote: "The Cat Hub has been a lifesaver! I used the food guide to finally find a brand my picky eater enjoys, and the store has the most unique toys. Highly recommended!",
    author: "Jessica P.",
    pet: "Mittens",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/eff5503a-bc6d-422a-b604-78b76af9d41c.webp"
  },
  {
    quote: "I never thought I could teach my cat tricks, but the 'high-five' guide was so easy to follow. We had it down in a week! It's a fun way to interact with him.",
    author: "David L.",
    pet: "Leo",
    avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/6474d0b0-889d-4da3-8e7a-780d21170f40.webp"
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-secondary/10 to-background px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              What Our <span className="text-gradient">Cat Parents</span> Say
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Don't just take our word for it, hear from our community
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-card/50 backdrop-blur-sm border-border h-full paws-card">
                <CardContent className="p-6">
                  <div className="flex flex-col h-full">
                    <div className="mb-6 relative">
                      <Quote className="w-10 h-10 text-primary/20 absolute -top-2 -left-2" />
                      <p className="text-card-foreground text-lg relative z-10 pl-6">
                        "{testimonial.quote}"
                      </p>
                    </div>
                    
                    <div className="mt-auto flex items-center">
                      <Avatar className="h-12 w-12 mr-3 border-2 border-primary/20">
                        <AvatarImage src={testimonial.avatar} alt={testimonial.author} />
                        <AvatarFallback className="bg-primary/20 text-primary">
                          {testimonial.author.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-card-foreground font-medium">{testimonial.author}</p>
                        <p className="text-muted-foreground text-sm">& {testimonial.author === "Jessica P." ? "her" : "his"} cat, {testimonial.pet}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
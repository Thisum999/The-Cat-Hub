import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Lightbulb, ShoppingBag, Newspaper } from "lucide-react";

const features = [
  {
    icon: <BookOpen className="w-10 h-10 text-primary" />,
    title: "Expert Care & Food Guides",
    description: "Learn the secrets to a healthy cat. Our guides cover everything from nutrition and choosing the right food to daily care routines.",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/9f0bfc29-eed7-4778-b7c0-9667525c1b37.webp",
    link: "/food-guide"
  },
  {
    icon: <Lightbulb className="w-10 h-10 text-primary" />,
    title: "Unlock Your Cat's Potential",
    description: "Bond with your cat in a new way! Discover our step-by-step guides to teaching your cat fun and impressive tricks like 'high-five' and 'fetch'.",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/24685b55-4801-48c6-9a68-cf535f33c3f8.webp",
    link: "/tricks"
  },
  {
    icon: <Newspaper className="w-10 h-10 text-primary" />,
    title: "Daily Cat Blog",
    description: "Stay up to date with our daily blog posts featuring cat care tips, behavior insights, and fun DIY projects for you and your feline friend.",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/30e1d8cf-8c3f-4f9d-ae2a-00e854f3d68d.webp",
    link: "/blog"
  },
  {
    icon: <ShoppingBag className="w-10 h-10 text-primary" />,
    title: "The Cat's Meow Store",
    description: "We've scoured the internet to find the best toys, beds, and gadgets. Our store features hand-picked products your cat will absolutely love.",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/aa03836a-ebc9-428b-bfc1-c30fda3149b8.webp",
    link: "/store"
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-20 bg-background px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Your <span className="text-gradient">Feline Friend</span> Deserves The Best
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Discover everything you need to know about cat care, training, and products
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-card border-border h-full paws-card overflow-hidden">
                <CardContent className="p-0 flex flex-col h-full">
                  {/* Feature image */}
                  <div className="w-full h-48 overflow-hidden">
                    <img 
                      src={feature.image}
                      alt={feature.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                  </div>
                  
                  {/* Feature content */}
                  <div className="p-6 flex-grow">
                    <div className="mb-4">{feature.icon}</div>
                    <h3 className="text-xl font-semibold mb-2 text-card-foreground">{feature.title}</h3>
                    <p className="text-muted-foreground mb-6">{feature.description}</p>
                    
                    <div className="mt-auto">
                      <Button 
                        asChild 
                        variant="outline" 
                        className="border-primary text-foreground hover:bg-primary/10 hover:text-primary w-full"
                      >
                        <Link to={feature.link}>Learn More</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { LoaderCircle } from "lucide-react";

interface AdInterstitialProps {
  isOpen: boolean;
  onClose: () => void;
  productName?: string;
}

const AdInterstitial = ({ isOpen, onClose, productName }: AdInterstitialProps) => {
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (isOpen && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
    } else if (isOpen && countdown === 0) {
      setTimeout(() => {
        onClose();
        alert(`Simulating redirection to AliExpress product page${productName ? ' for ' + productName : ''}.`);
      }, 500);
    }

    return () => {
      clearTimeout(timer);
    };
  }, [countdown, isOpen, onClose, productName]);

  useEffect(() => {
    if (isOpen) {
      setCountdown(3);
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <div className="text-center p-4">
          <div className="w-16 h-16 mx-auto mb-4 relative">
            <div className="absolute inset-0 rounded-full border-4 border-muted"></div>
            <div 
              className="absolute inset-0 rounded-full border-4 border-t-primary animate-spin"
              style={{ animationDuration: '1s' }}
            ></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <LoaderCircle className="w-8 h-8 text-primary animate-pulse" />
            </div>
          </div>
          
          <h2 className="text-xl font-semibold mb-2">One Moment Please...</h2>
          
          <p className="text-muted-foreground mb-6">
            Thank you for supporting The Cat Hub! You are now being redirected to our partner's site. 
            Our ads and partners help keep this site free.
          </p>
          
          <div className="text-lg font-medium text-primary">
            Redirecting in {countdown}...
          </div>
          
          <div className="mt-6">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="border-primary text-foreground hover:bg-primary/10 hover:text-primary"
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AdInterstitial;
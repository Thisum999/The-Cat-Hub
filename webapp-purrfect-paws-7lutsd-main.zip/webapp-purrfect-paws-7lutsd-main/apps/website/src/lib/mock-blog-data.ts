import { format, subDays } from "date-fns";

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  coverImage: string;
  author: {
    name: string;
    avatar: string;
  };
  publishedDate: string;
  tags: string[];
  readingTime: number;
}

// Generate the current date and previous dates for posts
const today = new Date();
const formatDate = (date: Date) => format(date, "yyyy-MM-dd");

export const generateTodayDate = () => {
  return format(today, "MMMM d, yyyy");
};

// Mock blog posts with the current date for the first post
export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "10 Signs Your Cat is Actually Happy",
    excerpt: "Learn to read your cat's subtle signals of contentment and joy. These hidden signs might surprise you!",
    content: `
# 10 Signs Your Cat is Actually Happy

Cats can be mysterious creatures, often leaving us wondering if they're truly content with their lives under our care. Unlike dogs who wag their tails and shower us with affection, cats express their happiness in more subtle ways. Here are ten signs that your feline friend is genuinely happy:

## 1. The Slow Blink

When your cat looks at you and slowly closes and opens their eyes, they're essentially blowing you a kiss in cat language! This gesture, often called a "cat kiss," indicates that your cat feels safe and comfortable around you.

## 2. Purring

While cats purr for various reasons, including when they're injured or stressed, a cat that purrs while being petted or cuddled is usually expressing contentment.

## 3. Kneading

That adorable behavior where your cat pushes their paws against a soft surface (often your lap) is a sign of happiness. This behavior originates from kittenhood when they kneaded their mother's belly to stimulate milk flow.

## 4. Exposed Belly

When a cat rolls over and exposes their belly, they're showing ultimate trust. The stomach is a vulnerable area, and displaying it means they feel secure in your presence.

## 5. Relaxed Posture

A happy cat will have a relaxed body, with ears facing forward and tail either still or gently swaying.

## 6. Playing

Cats that engage in play are generally happy and healthy. Regular play sessions indicate a content cat with energy to burn.

## 7. Healthy Appetite

A cat that eats well is usually a happy cat. Changes in appetite can often indicate health issues or stress.

## 8. Grooming

Cats that maintain good grooming habits are typically content. Excessive grooming might indicate stress, but regular grooming means they're comfortable.

## 9. Greeting You

Does your cat come to the door when you arrive home? This is a clear sign that they're happy to see you and enjoy your company.

## 10. Sleeping Near You

Cats are vulnerable when they sleep. If your cat chooses to nap near you or on you, it means they trust you completely and enjoy your presence.

Understanding these signs can help strengthen the bond between you and your feline companion. Remember, every cat is unique, and they may express happiness in their own individual ways. The key is to pay attention and learn your particular cat's language of contentment.
    `,
    coverImage: "https://storage.googleapis.com/fenado-ai-farm-public/generated/30e1d8cf-8c3f-4f9d-ae2a-00e854f3d68d.webp",
    author: {
      name: "Dr. Whiskers",
      avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/0b1ab6a9-5c2d-4ffc-9c99-07b4a581a8d0.webp"
    },
    publishedDate: format(today, "MMMM d, yyyy"),
    tags: ["cat behavior", "cat happiness", "pet care"],
    readingTime: 5
  },
  {
    id: "2",
    title: "The Perfect Diet for Indoor Cats",
    excerpt: "Indoor cats have specific dietary needs. Find out how to keep them healthy and happy with the right nutrition plan.",
    content: `
# The Perfect Diet for Indoor Cats

Indoor cats lead different lives than their outdoor counterparts, and as such, they have unique dietary requirements. Ensuring your indoor cat receives proper nutrition is essential for their long-term health and happiness.

## Understanding Indoor Cat Needs

Indoor cats typically:
- Get less exercise
- Experience fewer environmental stimuli
- Have no access to natural prey or plants
- Live longer than outdoor cats

These factors mean their diet needs special consideration.

## Key Components of an Indoor Cat Diet

### Calorie Control

Indoor cats burn fewer calories, making them prone to obesity. Their food should have:
- Appropriate calorie content
- Higher fiber to help them feel full
- Controlled fat levels

### Protein Quality

High-quality animal protein should be the first ingredient in your cat's food. Cats are obligate carnivores, meaning they require animal protein to thrive.

### Hairball Management

Indoor cats spend more time grooming and therefore ingest more hair. Their diet should include:
- Adequate fiber to help pass hairballs
- Specific ingredients like psyllium that assist with hairball control

### Hydration

Many cats don't drink enough water, which can lead to urinary tract issues. Consider:
- Wet food as part of their diet
- Fresh water sources (fountains often encourage drinking)
- Multiple water stations throughout your home

### Essential Nutrients

Make sure your cat's food contains:
- Taurine (essential amino acid for heart and eye health)
- Vitamin A
- Fatty acids for skin and coat health
- Appropriate mineral balance for urinary health

## Feeding Schedule

Most adult indoor cats do well with two measured meals per day. Avoid free-feeding as it often leads to overeating and obesity.

## Special Considerations

### Age-Specific Nutrition

Kittens, adults, and senior cats have different nutritional needs. Always choose food appropriate for your cat's life stage.

### Health Conditions

Cats with specific health issues may require prescription diets. Common conditions include:
- Urinary tract disease
- Kidney disease
- Diabetes
- Food allergies

## Treats and Supplements

Treats should make up no more than 10% of your cat's daily caloric intake. Consider:
- Healthy options like freeze-dried meat
- Dental treats for oral health
- Avoiding human food as treats

## Transitioning Foods

When changing your cat's diet, do so gradually over 7-10 days to prevent digestive upset.

By paying careful attention to your indoor cat's nutritional needs, you can help ensure they live a long, healthy, and happy life. Always consult with your veterinarian before making significant changes to your cat's diet, especially if they have existing health conditions.
    `,
    coverImage: "https://storage.googleapis.com/fenado-ai-farm-public/generated/6d79e7a3-4b2e-4a85-a3ea-e1d1e6c9e7be.webp",
    author: {
      name: "Feline Foodie",
      avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/7e6a5c75-7a0c-4a5f-a2c3-4b097e8f3d1a.webp"
    },
    publishedDate: format(subDays(today, 1), "MMMM d, yyyy"),
    tags: ["cat nutrition", "indoor cats", "pet health"],
    readingTime: 7
  },
  {
    id: "3",
    title: "Understanding Your Cat's Body Language",
    excerpt: "Cats communicate primarily through body language. Learn to decode what your feline friend is really saying.",
    content: `
# Understanding Your Cat's Body Language

Cats are expressive creatures, but they communicate in ways that are often subtle and easy to misinterpret. Learning to read your cat's body language can help you understand their needs, moods, and desires, ultimately strengthening your bond.

## The Tail Tells a Tale

Your cat's tail is perhaps their most expressive feature:

- **Tail held high**: A confident, happy cat
- **Puffed up tail**: Fear or aggression
- **Low or tucked tail**: Anxiety or submission
- **Swishing tail**: Concentration or irritation
- **Quivering tail**: Excitement or marking territory

## Ear Positions

Cats' ears move independently and can signal their emotional state:

- **Forward-facing**: Alert, interested, or content
- **Flattened against head**: Fear or aggression
- **Swiveling**: Listening and monitoring surroundings
- **Slightly back**: Mild irritation or uncertainty

## Eye Communication

A cat's eyes can reveal much about their mood:

- **Slow blinks**: Contentment and trust
- **Dilated pupils**: Excitement or fear
- **Constricted pupils**: Aggression or bright conditions
- **Half-closed eyes**: Relaxation and trust

## Body Postures

Overall body language provides important context:

- **Arched back with puffed fur**: Fear or aggression
- **Exposed belly**: Trust (though not always an invitation for belly rubs)
- **Loaf position** (tucked paws): Contentment and relaxation
- **Hiding or seeking high places**: Anxiety or need for security

## Vocalizations Combined with Body Language

While this article focuses on body language, vocalizations add context:

- **Purring with relaxed body**: Contentment
- **Purring with tense body**: Self-soothing when in pain or distress
- **Meowing with tail up**: Friendly greeting
- **Growling with flattened ears**: Clear warning to back off

## Common Misinterpretations

- **Wagging tail**: Unlike dogs, a cat wagging their tail often signals agitation
- **Purring**: Not always a sign of happiness; can also indicate stress or pain
- **Belly exposure**: May be a sign of trust but not necessarily an invitation for touch
- **Kneading**: Shows contentment but can also indicate anxiety in some contexts

## Reading the Whole Picture

The key to understanding cat body language is to observe multiple signals together. A single cue can mean different things in different contexts.

For example, a cat with dilated pupils could be playful if their body is relaxed and ears are forward, but the same dilated pupils with flattened ears and puffed fur indicate fear or aggression.

By paying attention to these subtle cues, you'll develop a deeper understanding of your cat's emotional state and needs, allowing you to respond appropriately and build a stronger relationship based on mutual understanding.
    `,
    coverImage: "https://storage.googleapis.com/fenado-ai-farm-public/generated/9c8d4f5e-6b7a-4c8d-9e2f-1a3b5c7d9e8f.webp",
    author: {
      name: "Cleo Pawsington",
      avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/2a3b4c5d-6e7f-8g9h-0i1j-2k3l4m5n6o7p.webp"
    },
    publishedDate: format(subDays(today, 3), "MMMM d, yyyy"),
    tags: ["cat behavior", "pet communication", "feline body language"],
    readingTime: 6
  },
  {
    id: "4",
    title: "DIY Cat Toys That Won't Break the Bank",
    excerpt: "Entertain your feline friend with these simple homemade toys that use items you already have at home.",
    content: `
# DIY Cat Toys That Won't Break the Bank

Cats don't need expensive toys to be entertained. With a bit of creativity and some household items, you can create engaging toys that will keep your feline friend active and mentally stimulated. Here are some simple DIY cat toy ideas that won't break the bank.

## Paper Ball Bonanza

The simplest toys are often the most effective. Crumple up a piece of paper into a tight ball, and you've got an instant cat toy. The crinkly sound and unpredictable movement make these irresistible to many cats.

**Materials needed:**
- Paper (receipts, junk mail, or newspaper work fine)

**How to make it:**
1. Crumple the paper into a tight ball about 1-2 inches in diameter
2. Toss it across the floor and watch your cat pounce

## Sock Fish

This simple toy uses an old sock and some catnip to create an enticing toy for your feline friend.

**Materials needed:**
- One clean sock (preferably a colorful one)
- Dried catnip
- Cotton balls or scrap fabric for stuffing
- Thread or string

**How to make it:**
1. Fill the toe of the sock with a pinch of catnip
2. Add stuffing to fill out the "head" of the fish
3. Tie off the stuffed portion with string to create the fish head
4. Cut the remaining part of the sock into 2-3 strips to form the "tail"
5. Tie a knot at the end of the sock to keep everything secure

## Toilet Paper Roll Puzzle

Turn an empty toilet paper roll into a puzzle feeder that will challenge your cat's problem-solving skills.

**Materials needed:**
- Empty toilet paper roll
- Cat treats or kibble

**How to make it:**
1. Fold in one end of the toilet paper roll
2. Place a few treats inside
3. Fold in the other end
4. Cut small holes in the sides of the roll (large enough for treats to fall out when batted around)
5. Let your cat figure out how to get the treats

## T-shirt Rope Toy

Create a durable rope toy from old t-shirts that's perfect for wrestling and bunny-kicking.

**Materials needed:**
- Old t-shirt
- Scissors

**How to make it:**
1. Cut the t-shirt into 3-4 inch wide strips
2. Stretch the strips to make them curl
3. Braid three strips together
4. Tie knots at both ends to secure

## Bottle Cap Hockey

This simple toy provides endless entertainment for cats who enjoy batting small objects.

**Materials needed:**
- Clean plastic bottle cap

**How to make it:**
1. That's it! Just place the cap on a smooth floor
2. Flick it to get your cat interested
3. Watch as your cat becomes a hockey star

## Wand Toy Refresh

If you have an old wand toy with a broken attachment, don't throw it away! Create a new attachment.

**Materials needed:**
- Old wand toy stick
- String or ribbon
- Items to attach (feathers from an old pillow, strips of fabric, crinkly paper)

**How to make it:**
1. Tie a 2-foot length of string to the end of the wand
2. Attach your chosen materials to the end of the string
3. Ensure all attachments are secure to prevent choking hazards

## Safety Tips

- Always supervise play with homemade toys
- Avoid small parts that could be swallowed
- Remove string toys after playtime to prevent entanglement
- Check toys regularly for wear and tear
- Discard damaged toys that could pose a hazard

With these simple DIY toys, you can keep your cat entertained and active without spending a fortune. The best part is that when they inevitably get bored with one toy, you can quickly and inexpensively create something new to capture their interest again.
    `,
    coverImage: "https://storage.googleapis.com/fenado-ai-farm-public/generated/1a2b3c4d-5e6f-7g8h-9i0j-1k2l3m4n5o6p.webp",
    author: {
      name: "Crafty Cat Lady",
      avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/5a6b7c8d-9e0f-1a2b-3c4d-5e6f7g8h9i0j.webp"
    },
    publishedDate: format(subDays(today, 5), "MMMM d, yyyy"),
    tags: ["DIY", "cat toys", "pet entertainment"],
    readingTime: 5
  },
  {
    id: "5",
    title: "Common Cat Health Issues and When to See the Vet",
    excerpt: "Learn to spot the early warning signs of common cat health problems and know when it's time for a professional opinion.",
    content: `
# Common Cat Health Issues and When to See the Vet

Cats are masters at hiding illness and discomfort. This evolutionary trait, designed to prevent appearing vulnerable in the wild, can make it challenging for cat owners to recognize when their feline friends need medical attention. This guide will help you identify common health issues and understand when it's time to consult a veterinarian.

## Urinary Tract Issues

Urinary problems are common in cats, especially males, and can quickly become life-threatening.

**Warning signs:**
- Frequent trips to the litter box with little or no urine production
- Straining in the litter box
- Crying while urinating
- Blood in urine
- Urinating outside the litter box
- Excessive licking of genital area

**When to see the vet:**
**IMMEDIATELY** if your cat is straining to urinate but producing little or no urine, particularly male cats. This could indicate a urinary blockage, which is a medical emergency that can be fatal within 24-48 hours.

## Dental Disease

Dental issues affect the majority of cats over three years old.

**Warning signs:**
- Bad breath
- Drooling
- Difficulty eating
- Pawing at mouth
- Red, swollen, or bleeding gums
- Missing or loose teeth
- Yellow/brown tartar buildup on teeth

**When to see the vet:**
Schedule an appointment within a week if you notice these symptoms. If your cat stops eating or seems in pain, seek care within 24-48 hours.

## Vomiting and Diarrhea

Occasional hairballs are normal, but frequent vomiting or diarrhea requires attention.

**Warning signs:**
- Vomiting more than once a week
- Diarrhea lasting more than 24 hours
- Blood in vomit or stool
- Lethargy accompanying digestive issues
- Decreased appetite
- Signs of abdominal pain

**When to see the vet:**
For occasional vomiting in an otherwise healthy cat, monitor for 24 hours. Seek immediate care if vomiting is severe, contains blood, or is accompanied by lethargy or pain. For diarrhea, contact your vet if it persists more than 24-48 hours or is accompanied by other symptoms.

## Respiratory Issues

Cats can suffer from various respiratory conditions, from simple colds to more serious infections.

**Warning signs:**
- Sneezing or nasal discharge
- Coughing
- Wheezing or labored breathing
- Lethargy
- Decreased appetite
- Fever

**When to see the vet:**
Mild sneezing or clear nasal discharge can be monitored for 24-48 hours. Seek immediate care if your cat is struggling to breathe, breathing with mouth open, or has blue-tinged gums. Persistent coughing or wheezing warrants a vet visit within 24 hours.

## Weight Changes

Significant weight loss or gain can indicate underlying health issues.

**Warning signs:**
- Noticeable weight loss despite normal or increased appetite
- Sudden weight gain
- Changes in drinking or urination habits accompanying weight changes
- Increased hunger but maintaining or losing weight

**When to see the vet:**
Schedule an appointment within a week for noticeable weight changes. If weight loss is rapid or accompanied by other symptoms, seek care sooner.

## Skin and Coat Problems

Healthy cats have smooth, clean coats without excessive scaling or redness.

**Warning signs:**
- Excessive scratching
- Hair loss
- Red, inflamed skin
- Scabs or open sores
- Excessive grooming
- Dull coat
- Visible parasites

**When to see the vet:**
Most skin issues can be addressed at a regular appointment unless there are open wounds, severe discomfort, or your cat is damaging their skin through scratching or overgrooming.

## Behavior Changes

Significant behavior changes often indicate health problems.

**Warning signs:**
- Increased aggression
- Hiding more than usual
- Decreased interaction with family
- Litter box avoidance
- Vocalization changes
- Confusion or disorientation
- Changes in sleep patterns

**When to see the vet:**
Schedule an appointment within a week for behavior changes. Sudden extreme behavior changes, especially in older cats, warrant more prompt attention.

## Emergency Situations - Seek Immediate Veterinary Care

- Difficulty breathing
- Seizures
- Collapse or inability to stand
- Severe bleeding
- Known ingestion of toxic substances
- Severe trauma (falls, being hit by car)
- Straining to urinate without producing urine
- Dragging rear legs or inability to use limbs
- Extreme pain
- Body temperature over 104°F (40°C) or below 99°F (37.2°C)

Remember that early intervention often leads to better outcomes and less expensive treatment. When in doubt, call your veterinary clinic for guidance. Most clinics are happy to help you determine whether your cat's symptoms warrant an immediate visit or can wait for a scheduled appointment.
    `,
    coverImage: "https://storage.googleapis.com/fenado-ai-farm-public/generated/2p3q4r5s-6t7u-8v9w-0x1y-2z3a4b5c6d7e.webp",
    author: {
      name: "Dr. Whiskers",
      avatar: "https://storage.googleapis.com/fenado-ai-farm-public/generated/0b1ab6a9-5c2d-4ffc-9c99-07b4a581a8d0.webp"
    },
    publishedDate: format(subDays(today, 7), "MMMM d, yyyy"),
    tags: ["cat health", "veterinary care", "pet wellness"],
    readingTime: 8
  }
];

// Function to get a blog post by ID
export const getBlogPostById = (id: string): BlogPost | undefined => {
  return blogPosts.find(post => post.id === id);
};
import RootLayout from "@/components/layout/RootLayout";
import HeroSection from "@/components/home/HeroSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import TestimonialsSection from "@/components/home/TestimonialsSection";
import CtaSection from "@/components/home/CtaSection";

export default function Home() {
  // Set document title
  document.title = "The Cat Hub - Your Ultimate Guide to a Happy Cat";
  
  return (
    <RootLayout>
      <HeroSection />
      <FeaturesSection />
      <TestimonialsSection />
      <CtaSection />
    </RootLayout>
  );
}
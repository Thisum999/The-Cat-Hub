import { useState } from "react";
import { motion } from "framer-motion";
import { Lightbulb, Star, Clock, PawPrint } from "lucide-react";
import RootLayout from "@/components/layout/RootLayout";
import PageHeader from "@/components/shared/PageHeader";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const tricks = [
  {
    id: "high-five",
    title: "How to Teach Your Cat to High-Five",
    difficulty: "Easy",
    timeRequired: "1-2 weeks",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/24685b55-4801-48c6-9a68-cf535f33c3f8.webp",
    steps: [
      "Grab some of your cat's favorite treats.",
      "When your cat naturally lifts its paw, say \"High-five!\" and give them a treat.",
      "Repeat this process, gradually starting to present your hand for them to touch.",
      "With patience, your cat will learn to tap your hand on command!"
    ]
  },
  {
    id: "fetch",
    title: "How to Teach Your Cat to Fetch",
    difficulty: "Medium",
    timeRequired: "2-4 weeks",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/9827c7d8-8d75-4e77-a1be-896ba4cd3c04.webp",
    steps: [
      "Find a small, light toy your cat loves.",
      "Throw it a short distance. If they go after it, praise them.",
      "If they pick it up, offer a treat to encourage them to bring it back to you.",
      "This takes time! Keep sessions short and fun."
    ]
  },
  {
    id: "sit",
    title: "The Classic 'Sit' Command",
    difficulty: "Easy",
    timeRequired: "1-2 weeks",
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/cf90333b-6701-40b8-b71e-3ed4a2e7a643.webp",
    steps: [
      "Hold a treat just above your cat's head, moving it slightly back.",
      "As your cat looks up, they'll naturally sit down to maintain balance.",
      "The moment they sit, say \"Sit\" and give them the treat.",
      "Practice daily for short sessions until they associate the command with the action."
    ]
  }
];

const TricksPage = () => {
  // Set document title
  document.title = "Cat Tricks - The Cat Hub";
  
  const [selectedTrick, setSelectedTrick] = useState(tricks[0].id);
  
  return (
    <RootLayout>
      <PageHeader
        title="Fun Tricks to Teach Your Cat"
        description="Training is a great way to prevent boredom and strengthen your bond. Here are a few fun tricks to get you started."
        icon={<Lightbulb className="w-8 h-8 text-primary" />}
      />
      
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <Tabs defaultValue={tricks[0].id} value={selectedTrick} onValueChange={setSelectedTrick} className="w-full">
          <TabsList className="grid grid-cols-3 mb-8">
            {tricks.map((trick) => (
              <TabsTrigger key={trick.id} value={trick.id} className="text-sm sm:text-base">
                {trick.title.split('How to Teach Your Cat to ').pop().split('The Classic ').pop()}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {tricks.map((trick) => (
            <TabsContent key={trick.id} value={trick.id}>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  className="order-2 lg:order-1"
                >
                  <h2 className="text-2xl sm:text-3xl font-bold mb-4">{trick.title}</h2>
                  
                  <div className="flex flex-wrap gap-3 mb-6">
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      <span>Difficulty: {trick.difficulty}</span>
                    </Badge>
                    
                    <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Time: {trick.timeRequired}</span>
                    </Badge>
                  </div>
                  
                  <div className="space-y-6 mt-8">
                    <h3 className="text-xl font-medium flex items-center gap-2">
                      <PawPrint className="w-5 h-5 text-primary" />
                      Step-by-Step Instructions
                    </h3>
                    
                    <ol className="space-y-4">
                      {trick.steps.map((step, index) => (
                        <motion.li 
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: 0.1 * index }}
                          className="flex gap-4"
                        >
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
                            {index + 1}
                          </div>
                          <p className="text-muted-foreground">{step}</p>
                        </motion.li>
                      ))}
                    </ol>
                    
                    <div className="bg-muted p-4 rounded-lg mt-8">
                      <p className="text-muted-foreground text-sm">
                        <strong className="text-foreground">Pro Tip:</strong> Keep training sessions short (5-10 minutes) and always end on a positive note. Consistency is key - practice a little bit each day rather than one long session once a week.
                      </p>
                    </div>
                  </div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  className="order-1 lg:order-2"
                >
                  <Card className="overflow-hidden paws-card h-full">
                    <div className="aspect-video w-full">
                      <img 
                        src={trick.image} 
                        alt={trick.title} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h4 className="text-lg font-medium mb-2">{trick.title}</h4>
                      <p className="text-muted-foreground text-sm">
                        This trick helps build trust between you and your cat while providing mental stimulation.
                      </p>
                    </CardContent>
                    <CardFooter className="bg-muted/30 p-4 text-xs text-muted-foreground">
                      Remember to be patient and use positive reinforcement!
                    </CardFooter>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
        
        <div className="paws-section-divider"></div>
        
        <div className="text-center max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold mb-4">Ready to Try These Tricks?</h3>
          <p className="text-muted-foreground mb-6">
            Remember that every cat is different. Some may learn quickly while others need more time.
            The most important thing is that you're spending quality time together and strengthening your bond.
          </p>
        </div>
      </div>
    </RootLayout>
  );
};

export default TricksPage;
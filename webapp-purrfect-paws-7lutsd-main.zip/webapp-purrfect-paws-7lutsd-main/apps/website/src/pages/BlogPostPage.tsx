import RootLayout from "@/components/layout/RootLayout";
import BlogPost from "@/components/blog/BlogPost";

const BlogPostPage = () => {
  return (
    <RootLayout>
      <BlogPost />
    </RootLayout>
  );
};

export default BlogPostPage;
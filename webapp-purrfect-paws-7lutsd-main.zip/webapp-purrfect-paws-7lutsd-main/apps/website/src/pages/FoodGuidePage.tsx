import { motion } from "framer-motion";
import { BookOpen, Check, AlertCircle } from "lucide-react";
import RootLayout from "@/components/layout/RootLayout";
import PageHeader from "@/components/shared/PageHeader";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";

const FoodGuidePage = () => {
  // Set document title
  document.title = "Cat Food Guide - The Cat Hub";
  
  return (
    <RootLayout>
      <PageHeader
        title="The Ultimate Cat Food Guide"
        description="Navigating the world of cat food can be confusing. Our guide breaks down the basics to help you make healthy choices for your companion."
        icon={<BookOpen className="w-8 h-8 text-primary" />}
      />
      
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="wet-vs-dry">
                  <AccordionTrigger className="text-xl font-medium">
                    Wet Food vs. Dry Food: What's the Difference?
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-4">
                      <img 
                        src="https://storage.googleapis.com/fenado-ai-farm-public/generated/7888addb-2c5b-4c4b-b805-6c7bee6701a2.webp" 
                        alt="Wet food vs dry food comparison" 
                        className="w-full h-auto rounded-lg mb-4"
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="text-lg font-medium mb-2 text-primary">Wet Food Benefits</h4>
                          <ul className="space-y-2">
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Higher water content helps with hydration</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Often more palatable for picky eaters</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Usually higher in protein and lower in carbohydrates</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Easier to eat for cats with dental issues</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="text-lg font-medium mb-2 text-primary">Dry Food Benefits</h4>
                          <ul className="space-y-2">
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>More convenient and can be left out longer</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Generally more cost-effective</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Can help with dental health through crunching</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Higher caloric density, good for underweight cats</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      
                      <p className="text-muted-foreground mt-4">
                        <strong className="text-foreground">Expert Recommendation:</strong> A mix of both wet and dry food often provides the best balance of nutrition and convenience. Consider feeding wet food once or twice daily, with dry food available for free feeding or as treats.
                      </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="reading-labels">
                  <AccordionTrigger className="text-xl font-medium">
                    Reading a Cat Food Label
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-4">
                      <img 
                        src="https://storage.googleapis.com/fenado-ai-farm-public/generated/222e27c5-d0ed-4d79-986b-39496a936c95.webp" 
                        alt="Cat food label being examined" 
                        className="w-full h-auto rounded-lg mb-4"
                      />
                      
                      <h4 className="text-lg font-medium">What to Look For:</h4>
                      <ul className="space-y-3">
                        <li className="flex gap-2">
                          <Check className="w-5 h-5 text-primary flex-shrink-0" />
                          <div>
                            <strong>Named protein source as first ingredient</strong>
                            <p className="text-muted-foreground text-sm">Look for specific proteins like "chicken" or "salmon" rather than generic terms like "meat" or "animal derivatives"</p>
                          </div>
                        </li>
                        <li className="flex gap-2">
                          <Check className="w-5 h-5 text-primary flex-shrink-0" />
                          <div>
                            <strong>Appropriate fat content</strong>
                            <p className="text-muted-foreground text-sm">Adult cats typically need 20-24% protein and 9-18% fat in their diet</p>
                          </div>
                        </li>
                        <li className="flex gap-2">
                          <Check className="w-5 h-5 text-primary flex-shrink-0" />
                          <div>
                            <strong>Taurine</strong>
                            <p className="text-muted-foreground text-sm">An essential amino acid that cats cannot produce themselves</p>
                          </div>
                        </li>
                        <li className="flex gap-2">
                          <Check className="w-5 h-5 text-primary flex-shrink-0" />
                          <div>
                            <strong>AAFCO statement</strong>
                            <p className="text-muted-foreground text-sm">Indicates the food meets basic nutritional requirements</p>
                          </div>
                        </li>
                      </ul>
                      
                      <h4 className="text-lg font-medium mt-6">What to Avoid:</h4>
                      <ul className="space-y-3">
                        <li className="flex gap-2">
                          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />
                          <div>
                            <strong>Excessive fillers</strong>
                            <p className="text-muted-foreground text-sm">Corn, wheat gluten, and soy as main ingredients</p>
                          </div>
                        </li>
                        <li className="flex gap-2">
                          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />
                          <div>
                            <strong>Artificial colors and preservatives</strong>
                            <p className="text-muted-foreground text-sm">BHA, BHT, ethoxyquin, and artificial colors are best avoided</p>
                          </div>
                        </li>
                        <li className="flex gap-2">
                          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />
                          <div>
                            <strong>Generic meat by-products</strong>
                            <p className="text-muted-foreground text-sm">Unspecified animal sources that may vary in quality</p>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="special-diets">
                  <AccordionTrigger className="text-xl font-medium">
                    Special Dietary Needs
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="text-lg font-medium mb-2">Kitten Food</h4>
                          <p className="text-muted-foreground mb-4">
                            Kittens need more calories, protein, and certain nutrients to support their rapid growth and development.
                          </p>
                          <ul className="space-y-2">
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Higher protein content (30-35%)</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>More fat for energy and brain development</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Added DHA for cognitive development</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="text-lg font-medium mb-2">Senior Cat Food</h4>
                          <p className="text-muted-foreground mb-4">
                            Older cats (7+ years) have changing nutritional needs as they age.
                          </p>
                          <ul className="space-y-2">
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Easy to digest proteins</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Joint-supporting nutrients (glucosamine, chondroitin)</span>
                            </li>
                            <li className="flex gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0" />
                              <span>Adjusted phosphorus levels for kidney health</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="bg-muted p-4 rounded-lg mt-6">
                        <h4 className="text-lg font-medium mb-2">Medical Conditions</h4>
                        <p className="text-muted-foreground mb-4">
                          Cats with health issues often require prescription diets. Always consult your veterinarian before changing the diet of a cat with:
                        </p>
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Kidney disease</span>
                          </li>
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Diabetes</span>
                          </li>
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Urinary tract issues</span>
                          </li>
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Food allergies</span>
                          </li>
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Obesity</span>
                          </li>
                          <li className="flex gap-2 items-center">
                            <Check className="w-4 h-4 text-primary flex-shrink-0" />
                            <span>Dental disease</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </motion.div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="paws-card sticky top-20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">Quick Tips</h3>
                  
                  <div className="space-y-4">
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                        1
                      </div>
                      <p className="text-muted-foreground text-sm">
                        <strong className="text-foreground">Transition slowly</strong> when changing foods to avoid digestive upset.
                      </p>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                        2
                      </div>
                      <p className="text-muted-foreground text-sm">
                        <strong className="text-foreground">Fresh water</strong> should always be available, especially for cats on dry food.
                      </p>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                        3
                      </div>
                      <p className="text-muted-foreground text-sm">
                        <strong className="text-foreground">Monitor weight</strong> and adjust portions accordingly to prevent obesity.
                      </p>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                        4
                      </div>
                      <p className="text-muted-foreground text-sm">
                        <strong className="text-foreground">Consult your vet</strong> before making significant diet changes, especially for kittens, seniors, or cats with health issues.
                      </p>
                    </div>
                  </div>
                  
                  <div className="paws-section-divider"></div>
                  
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Remember</h4>
                    <p className="text-muted-foreground text-sm">
                      Every cat is unique. What works for one may not work for another. Pay attention to your cat's preferences and health needs.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </RootLayout>
  );
};

export default FoodGuidePage;
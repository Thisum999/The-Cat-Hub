import { useState } from "react";
import { motion } from "framer-motion";
import { ShoppingBag, Filter, Search, Star, Truck, ShieldCheck, Tag } from "lucide-react";
import RootLayout from "@/components/layout/RootLayout";
import PageHeader from "@/components/shared/PageHeader";
import AdInterstitial from "@/components/shared/AdInterstitial";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

// Product data
const products = [
  {
    id: 1,
    name: "Smart Interactive Cat Ball",
    description: "Self-rotating ball that keeps your cat entertained for hours.",
    price: 19.99,
    rating: 4.5,
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/7b0ba5fb-58eb-4874-8c05-5a86ed4d34ab.webp",
    category: "Toys & Entertainment"
  },
  {
    id: 2,
    name: "Plush Calming Cat Bed",
    description: "Ultra-soft and cozy to reduce anxiety and improve sleep.",
    price: 24.50,
    rating: 4.8,
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/e080a23c-f069-41d5-96f2-c79a0f6079cf.webp",
    category: "Beds & Furniture"
  },
  {
    id: 3,
    name: "Retractable Feather Wand",
    description: "The classic toy for interactive play sessions.",
    price: 9.99,
    rating: 4.3,
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/b99bac52-6239-4eea-b43f-dfb09756170a.webp",
    category: "Toys & Entertainment"
  },
  {
    id: 4,
    name: "Multi-Level Cat Tree",
    description: "A perfect climbing and scratching tower with multiple platforms.",
    price: 59.99,
    rating: 4.7,
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/9493f85a-e1dc-461c-8b56-767ae5fdbf35.webp",
    category: "Beds & Furniture"
  },
  {
    id: 5,
    name: "Self-Cleaning Litter Box",
    description: "Automatic cleaning system for less maintenance and better odor control.",
    price: 129.99,
    rating: 4.2,
    image: "https://storage.googleapis.com/fenado-ai-farm-public/generated/f7760828-f2e5-480d-9ac8-83b5cfaeb06e.webp",
    category: "Accessories"
  }
];

// Categories
const categories = [
  "Toys & Entertainment",
  "Beds & Furniture",
  "Grooming",
  "Accessories",
  "Food & Treats"
];

const StorePage = () => {
  // Set document title
  document.title = "The Cat's Meow Store - The Cat Hub";
  
  // State
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([0, 150]);
  const [isAdOpen, setIsAdOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string | undefined>();
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);
  
  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category);
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  // Handle buy button click
  const handleBuyClick = (productName: string) => {
    setSelectedProduct(productName);
    setIsAdOpen(true);
  };
  
  // Toggle category selection
  const toggleCategory = (category: string) => {
    setSelectedCategories(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category) 
        : [...prev, category]
    );
  };
  
  // Render star rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="w-4 h-4 fill-primary text-primary" />);
    }
    
    if (hasHalfStar) {
      stars.push(
        <span key="half" className="relative">
          <Star className="w-4 h-4 text-primary" />
          <Star className="w-4 h-4 fill-primary text-primary absolute top-0 left-0" style={{ clipPath: 'inset(0 50% 0 0)' }} />
        </span>
      );
    }
    
    const remainingStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-4 h-4 text-muted" />);
    }
    
    return <div className="flex">{stars}</div>;
  };
  
  return (
    <RootLayout>
      <PageHeader
        title="The Cat's Meow Store"
        description="Hand-picked products from AliExpress and other partners. Every purchase helps support our site!"
        icon={<ShoppingBag className="w-8 h-8 text-primary" />}
      />
      
      {/* Store benefits banner */}
      <div className="bg-muted py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="flex items-center justify-center gap-2">
              <Truck className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Fast shipping on all items</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Quality guaranteed products</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <Tag className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Best prices from our partners</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="w-full md:w-64 hidden md:block">
            <div className="sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-medium">Filters</h2>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => {
                    setSelectedCategories([]);
                    setPriceRange([0, 150]);
                  }}
                >
                  Reset
                </Button>
              </div>
              
              <div className="space-y-6">
                {/* Search */}
                <div>
                  <label htmlFor="desktop-search" className="text-sm font-medium mb-2 block">Search</label>
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      id="desktop-search"
                      placeholder="Search products..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <Separator />
                
                {/* Categories */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Categories</h3>
                  <div className="space-y-2">
                    {categories.map(category => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`category-${category}`} 
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => toggleCategory(category)}
                        />
                        <label 
                          htmlFor={`category-${category}`}
                          className="text-sm text-muted-foreground cursor-pointer"
                        >
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                {/* Price Range */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium">Price Range</h3>
                    <span className="text-xs text-muted-foreground">
                      ${priceRange[0]} - ${priceRange[1]}
                    </span>
                  </div>
                  <Slider
                    defaultValue={[0, 150]}
                    max={150}
                    step={1}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="my-6"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Main content */}
          <div className="flex-1">
            {/* Mobile filters and search */}
            <div className="md:hidden mb-6">
              <div className="flex gap-4 mb-4">
                <Sheet open={isMobileFiltersOpen} onOpenChange={setIsMobileFiltersOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="flex-1">
                      <Filter className="w-4 h-4 mr-2" />
                      Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px]">
                    <div className="py-6 space-y-6">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-lg font-medium">Filters</h2>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => {
                            setSelectedCategories([]);
                            setPriceRange([0, 150]);
                          }}
                        >
                          Reset
                        </Button>
                      </div>
                      
                      {/* Categories */}
                      <div>
                        <h3 className="text-sm font-medium mb-2">Categories</h3>
                        <div className="space-y-2">
                          {categories.map(category => (
                            <div key={category} className="flex items-center space-x-2">
                              <Checkbox 
                                id={`mobile-category-${category}`} 
                                checked={selectedCategories.includes(category)}
                                onCheckedChange={() => toggleCategory(category)}
                              />
                              <label 
                                htmlFor={`mobile-category-${category}`}
                                className="text-sm text-muted-foreground cursor-pointer"
                              >
                                {category}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <Separator />
                      
                      {/* Price Range */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-sm font-medium">Price Range</h3>
                          <span className="text-xs text-muted-foreground">
                            ${priceRange[0]} - ${priceRange[1]}
                          </span>
                        </div>
                        <Slider
                          defaultValue={[0, 150]}
                          max={150}
                          step={1}
                          value={priceRange}
                          onValueChange={setPriceRange}
                          className="my-6"
                        />
                      </div>
                      
                      <div className="pt-4">
                        <Button 
                          className="w-full" 
                          onClick={() => setIsMobileFiltersOpen(false)}
                        >
                          Apply Filters
                        </Button>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
                
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search products..."
                    className="pl-8 w-full"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              {/* Selected filters */}
              {selectedCategories.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedCategories.map(category => (
                    <Badge key={category} variant="secondary" className="flex items-center gap-1">
                      {category}
                      <button 
                        className="ml-1 rounded-full hover:bg-background/20 p-0.5"
                        onClick={() => toggleCategory(category)}
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
            
            {/* Results info */}
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium">
                {filteredProducts.length} {filteredProducts.length === 1 ? 'Product' : 'Products'}
              </h2>
              <div className="text-sm text-muted-foreground">
                Showing all available products
              </div>
            </div>
            
            {/* Products grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="h-full paws-card overflow-hidden">
                    <div className="aspect-square w-full overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      />
                    </div>
                    
                    <CardContent className="p-4">
                      <Badge variant="outline" className="mb-2 bg-primary/5 text-primary">
                        {product.category}
                      </Badge>
                      <h3 className="text-lg font-medium mb-1">{product.name}</h3>
                      <p className="text-muted-foreground text-sm mb-4">{product.description}</p>
                      
                      <div className="flex items-center justify-between mt-auto">
                        <div className="flex items-center gap-1">
                          {renderStars(product.rating)}
                          <span className="text-xs text-muted-foreground ml-1">({product.rating})</span>
                        </div>
                        <div className="font-medium text-lg">${product.price.toFixed(2)}</div>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="p-4 pt-0">
                      <Button 
                        className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                        onClick={() => handleBuyClick(product.name)}
                      >
                        Buy on AliExpress
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            {/* No results */}
            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Search className="w-6 h-6 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium mb-2">No products found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your filters or search term to find what you're looking for.
                </p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedCategories([]);
                    setPriceRange([0, 150]);
                  }}
                >
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Ad Interstitial */}
      <AdInterstitial 
        isOpen={isAdOpen} 
        onClose={() => setIsAdOpen(false)} 
        productName={selectedProduct}
      />
    </RootLayout>
  );
};

export default StorePage;
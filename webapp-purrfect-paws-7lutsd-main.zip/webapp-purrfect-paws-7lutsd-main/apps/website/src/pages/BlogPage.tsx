import RootLayout from "@/components/layout/RootLayout";
import BlogList from "@/components/blog/BlogList";
import { useEffect } from "react";

const BlogPage = () => {
  useEffect(() => {
    document.title = "Blog | The Cat Hub";
  }, []);

  return (
    <RootLayout>
      <BlogList />
    </RootLayout>
  );
};

export default BlogPage;
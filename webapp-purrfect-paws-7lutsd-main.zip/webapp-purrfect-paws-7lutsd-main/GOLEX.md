# GOLEX Knowledge Log

## Project Summary
The Cat Hub is a front-end prototype for a cat enthusiast website featuring cat care guides, training tricks, a daily updating blog, and a curated store with affiliate links to cat products on AliExpress. The site uses React, TypeScript, Vite, Tailwind CSS, and shadcn/ui components with a custom "Playful Paws" theme.

## Evolution Timeline
- 2025-08-07: Initial project setup with landing page, cat tricks guide, food guide, store, and contact pages.
- 2025-08-08: Added daily updating blog feature with multiple articles and individual post pages.

## Clarifications Needed
- None at this time.

## Repo Map
- `/app/repo/apps/website/src/App.tsx`: Main application component with routes configuration.
- `/app/repo/apps/website/src/index.css`: Global styles and theme definitions including custom "Playful Paws" theme.
- `/app/repo/apps/website/src/components/layout/RootLayout.tsx`: Main layout component used across all pages.
- `/app/repo/apps/website/src/components/layout/Header.tsx`: Site navigation header with mobile responsive menu.
- `/app/repo/apps/website/src/components/layout/Footer.tsx`: Site footer with links and social media icons.
- `/app/repo/apps/website/src/components/home/HeroSection.tsx`: Landing page hero section with main CTA buttons.
- `/app/repo/apps/website/src/components/home/FeaturesSection.tsx`: Landing page features section showcasing main site sections.
- `/app/repo/apps/website/src/components/home/TestimonialsSection.tsx`: Landing page testimonials from cat owners.
- `/app/repo/apps/website/src/components/home/CtaSection.tsx`: Landing page call-to-action section with store link.
- `/app/repo/apps/website/src/components/shared/AdInterstitial.tsx`: Reusable ad interstitial modal for affiliate links.
- `/app/repo/apps/website/src/components/shared/PageHeader.tsx`: Reusable page header component for inner pages.
- `/app/repo/apps/website/src/components/blog/BlogList.tsx`: Blog listing component showing all blog posts.
- `/app/repo/apps/website/src/components/blog/BlogPost.tsx`: Individual blog post display component with markdown rendering.
- `/app/repo/apps/website/src/components/blog/blog.css`: CSS styles for blog post content and markdown rendering.
- `/app/repo/apps/website/src/lib/mock-blog-data.ts`: Mock data for blog posts with daily updating date functionality.
- `/app/repo/apps/website/src/pages/Home.tsx`: Home/landing page combining all home components.
- `/app/repo/apps/website/src/pages/TricksPage.tsx`: Cat tricks training guides with step-by-step instructions.
- `/app/repo/apps/website/src/pages/FoodGuidePage.tsx`: Cat food information guide with accordions.
- `/app/repo/apps/website/src/pages/BlogPage.tsx`: Blog listing page displaying all blog posts.
- `/app/repo/apps/website/src/pages/BlogPostPage.tsx`: Individual blog post page with full article content.
- `/app/repo/apps/website/src/pages/StorePage.tsx`: Product store page with filters and affiliate product cards.
- `/app/repo/apps/website/src/pages/ContactPage.tsx`: Contact form and information page.
- `/app/repo/apps/website/src/pages/ErrorPage.tsx`: Custom 404 error page with navigation options.